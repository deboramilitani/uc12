package com.DataBasePI.DataBasePI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataBasePIApplicationTests {

	@Test
	void contextLoads() {
	}

}
